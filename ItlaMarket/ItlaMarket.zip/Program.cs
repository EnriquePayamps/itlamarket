﻿using System;

namespace ItlaMarket
{
    class Program
    {
        static void Main(string[] args)
        {
            MenuPrincipal menuPrincipal = new MenuPrincipal();
            menuPrincipal.ImprimirMenu();
        }
    }
}
